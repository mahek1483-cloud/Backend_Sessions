// JS - To make wedsites more interactive,more responsive
// Programming Lang - 
// FE - High level =>(v8-engine) low level
// BE - Js -> nodejs
// in.java -> javac in.java => in .class(byte) => java in => mc = > o/p
console.log("Hello World")
// variable -> It is store the address of value
// Type -> integer, Decimal ,Bo&value, String, array
// Syntax -> variable var_name=value; let  const
let x=10
console.log("The value is=",x)
console.log(typeof(x));

let name="mahek"
console.log("My name is",name)

let y=10/3
console.log("Decimal",y)

var array=[1,2,3,4];
var array1=[1,2,3,4,"Hello"];
console.log(array[2]);
console.log(array1[4]);
console.log(typeof(array));
console.log(typeof(array1));
 
let Student1={Stuname:"Mahek",
               stuRollnno:150,
               hobbies:['Anime','reels']
}
console.log(Student1)

// FUNCTION

function add(x,y){
     return x+y
}
console.log(add(2,4));