const express = require("express");
const mong = require('mongoose');

const app = express();
app.use(express.json());//middle ware

//mongodb://127.0.0.1:27017/

const db=mong.connect("mongodb://127.0.0.1:27017/Collegedbs")
db.then(() => console.log("Connected to Colegedbs database successfully!"))
db.catch((err) => console.error("Database connection error:", err));


const teacherSchema = new mong.Schema({
  name: { type: String, required: true },
  subject: { type: String, required: true },
  experience: { type: Number, default: 0 }
});

// Mongoose automatically creates a collection named "teachers" (plural)
const Teacher = mong.model('Teacher', teacherSchema);

app.listen(3000, () => {
console.log("Server running on port 3000");
})//start server on port number 3000

