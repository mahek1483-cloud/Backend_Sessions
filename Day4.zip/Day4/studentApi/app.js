const express = require("express");
const app = express();
app.use(express.json());//middle ware
let students = [{ id: 1, name: "Rahul", course: "BCA" }]//creating  dummy data
//implimenting get method
app.get("/students",(req,res)=>{
    res.json(students);
})
// get method for specific sutudent

app.get('/students/:id',(req,res)=>{
    //logic 
    // url - res 
      var idurl  = req.params.id

      for(i=0;i<students.length;i++){
         if(students[i].id == idurl){
            res.status(200).json(students[i]) //success
         }
      }
      //error msg 
      res.send(4).json({msg:"Student not found"})


})
app.listen(3000, () => {
console.log("Server running on port 3000");
})//start server on port number 3000