const express = require('express');
const app = express();
//route = home page = /
app.get('/', (req, res) => {
res.send('Hello from Express!');
});

//route = about page = /about
app.get('/about', (req, res) => {
res.send('About Page');
});

app.listen(8080, () => {
console.log('Server running on port 8080');
})